package com.example.warehouseinventoryapp.provider;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import com.google.android.material.internal.ParcelableSparseArray;

@Entity(tableName = "items")
public class Item{
    @PrimaryKey(autoGenerate = true)
    @NonNull
    @ColumnInfo(name = "itemId")
    private int id;

    @ColumnInfo(name = "itemName")
    private String itemName;
    @ColumnInfo(name = "itemDescription")
    private String itemDescription;
    @ColumnInfo(name = "itemQuantity")
    private int itemQuantity;
    @ColumnInfo(name = "itemIsFrozen")
    private boolean itemIsFrozen;
    @ColumnInfo(name = "itemCost")
    private double itemCost;


    public Item(String itemName, int itemQuantity, double itemCost, String itemDescription, boolean itemIsFrozen) {
        this.itemName = itemName;
        this.itemQuantity = itemQuantity;
        this.itemCost = itemCost;
        this.itemDescription = itemDescription;
        this.itemIsFrozen = itemIsFrozen;
    }

    public String getItemName() {
        return itemName;
    }

    public String getItemDescription() {
        return itemDescription;
    }

    public int getItemQuantity() {
        return itemQuantity;
    }

    public boolean isItemIsFrozen() {
        return itemIsFrozen;
    }

    public double getItemCost() {
        return itemCost;
    }

    public int getId(){return id;}

    public void setId(@NonNull int id){this.id = id;}
}
